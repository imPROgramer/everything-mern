module.exports={
    dburl: 'mongodb://127.0.0.1:27017',
    secret: 'shhhthisissecret',
    port : 9000
}  