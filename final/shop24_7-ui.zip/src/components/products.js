import { ProductCard} from '../components/product-card';


export function Products(props){
    const width = props.width;

    return (
        <>
            { props.products.map((product)=><ProductCard product={product} width={width}></ProductCard>) }
        </>
    )

}