import axios from 'axios';
import { useState } from 'react';
import {Card} from 'react-bootstrap';
import {Button } from 'react-bootstrap';

const cardStyle= {
    "borderRadius":"5px",
    "margin":"10px",
}
const cardImgStyle={
    "width": "80%",
    "height": "60%"
}

export function Banner(props){

    return(
        <Card style={cardStyle}>
            <Card.Img variant="top" src={'logo512.png'} height='300' width='400'/>
            {/* <Card.Body>
                <Card.Title></Card.Title>
                <Card.Text></Card.Text>
                <Button variant="light" type="button" disabled></Button>
                <Button variant="primary" type="button" onClick={addToCart}></Button>
            </Card.Body> */}
        </Card>
    )
}