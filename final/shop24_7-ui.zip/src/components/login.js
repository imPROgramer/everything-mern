import { Row, Col } from "react-bootstrap";
import { LoginCard } from "./login-card";
import { WelcomeMessageCard } from "./welcome-message";
import { RegisterCard } from "./register-card";

export function Login(props){
    console.log( props );
    return (
        <Row className="mt-4" style={{"marginRight":'0px', "marginLeft":'0px'}}>
            <Col md={2}></Col>
            <Col md={4}>
                <WelcomeMessageCard></WelcomeMessageCard>
            </Col>
            <Col md={4}>
                {props.isLogin ?<LoginCard/>: <RegisterCard/>}
            </Col>
            <Col md={2}></Col>
        </Row>
    )
}