import { Card, Button, Form } from 'react-bootstrap';
import { useState } from 'react';
import axios from 'axios';

export function LoginCard (){

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isFailed, setIsFailed] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        let data = {email, password}; //JSON.stringify()
        await axios.post('http://localhost:9000/api/v1/users/login',data)
             .then((response)=>{
                console.log(response);
                if(response.data.status == 'success'){
                    console.log("Redirect to Home page");
                    localStorage.setItem('token',response.data.accessToken);
                    localStorage.setItem('email',email);
                }else{
                    setIsFailed(true);
                }
             })
             .catch(err => {
                 setIsFailed(true);
             });
    }
    const handleEmail = (event) =>{
        setIsFailed(false);
        setEmail(event.target.value);
    }
    const handlePassword = (event) =>{
        setIsFailed(false);
        setPassword(event.target.value);
    }

    return(
        <Form onSubmit={handleSubmit}>
            <Card>
                <Card.Body className="justify-content-end">
                    <Card.Title>Login</Card.Title>
                    <Card.Text>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Email address</Form.Label>
                            <Form.Control data-testid="login-email" type="email" placeholder="Enter email"
                                value={email} onChange={handleEmail}/>
                            <Form.Text className="text-muted">
                                We'll never share your email with anyone else.
                            </Form.Text>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control data-testid="login-password" type="password" placeholder="Password" 
                                value={password} onChange={handlePassword}/>
                        </Form.Group>
                        {isFailed? <div className="alert alert-danger">Username or Password is incorrect</div> : "" }
                    </Card.Text>
                    <Button data-testid="login-submit" variant="primary" type="submit">Login</Button>
                </Card.Body>
            </Card>
        </Form>
    )
}