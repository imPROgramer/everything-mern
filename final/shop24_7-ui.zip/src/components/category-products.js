import axios from 'axios';
import { useEffect, useState } from 'react';
import { Row, Col } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import { Products } from "./products";

const rowStyle={
    "padding":" 0 12px"
};

const filterStyle={
    "margin":"auto",
    
};

export function CategoryProducts(props){

    const {catergory_id} =useParams();
    const [products,setProducts] = useState([]);

    const loadProducts = async () => {
        await axios.get(`http://localhost:9000/category/${catergory_id}`)
            .then((res)=>{
                console.log(res);
                setProducts(res.data);
                
            })
            .catch(err=>{
                console.log(err);
            });
    }

    useEffect( async ()=>{
        await loadProducts();
    },[])

    return (
        <Row className='w-75 d-flex justify-content-between'>
            <Col md={3} className="mt-4">Filter :</Col> 
                            {/* style={filterStyle} */}
                            {/* {catergory_id} */}
            <Col md={9}>
                <Row className="d-flex" style={rowStyle}>
                    <Products products={products} data-testid="homepage-product"
                        width={"30%"}></Products>
                </Row>
            </Col>
        </Row>
    );

}