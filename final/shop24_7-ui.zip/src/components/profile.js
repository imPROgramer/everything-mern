
import axios from "axios";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, Row, Col, Form, Button } from "react-bootstrap";

const loadingStyle = {
};
export function Profile(){

    const token = localStorage.getItem('token');
    const navigate = useNavigate();
    if(!token){
        console.log(token);
        navigate('/login');
    }

    let [isEditing, setIsEditing] = useState(false);
    let [isLoading, setIsLoading] = useState(false);

    let [firstName, setFirstName] = useState('');
    let [lastName, setLastName] = useState('');
    let [email, setEmail] = useState('');
    let [phone, setPhone] = useState('');
    let [interests, setInterests] = useState('');

    let [profileImage, setProfileImage] =useState('');
    let [profileImageError, setProfileImageError] = useState('');

    let [streetAddress, setStreetAddress] = useState('');
    let [city, setCity] = useState('');
    let [state, setState] = useState('');
    let [zipCode, setZipCode] = useState('');

    useEffect(async () => {
        await loadProfile(); 
    },[]);

    const loadProfile = async ()=>{
        const config= {
            headers:{"Authorization": token }
        };
        const data={email:localStorage.getItem('email')}
        await axios.post('http://localhost:9000/api/v1/profile',data,config)
            .then((res)=>{
                console.log(res);
                if(res.data.status == 'success'){
                    let user = res.data.profile;
                    setFirstName(user.firstName);
                    setLastName(user.lastName);
                    setEmail(user.email);
                    setInterests(user.interests||"");

                    setProfileImage(user.profileImage);

                    setStreetAddress(user.address?.streetAddress || "");
                    setCity(user.address?.city || '');
                    setState(user.address?.state || '');
                    setZipCode(user.address?.zipCode || '');
                }else{
                    navigate('/login');
                }
            })
            .catch((err)=>{
                console.log(err);
                navigate('/login');
            })
    }

    const handleEditBtnClick = ( event) =>{
        event.preventDefault();
        setIsEditing(true);
    }

    const handleAddressChange = async (event)=>{
        event.preventDefault();
        
        let address = {};
        
        address.streetAddress = streetAddress;
        address.city = city;
        address.state = state;
        address.zipCode = zipCode;

        console.log(address);
        const config= {
            headers:{"Authorization": token }
        };
        const data={address:address};
        
        await axios.patch('http://localhost:9000/api/v1/profile/address',data,config)
                    .then((res)=>{
                        console.log(res);
                        setIsEditing(false);
                    })
                    .catch((err)=>{
                        console.log(err);
                    })


    }

    const handleDeleteProfileImage = async (event)=>{
        event.preventDefault();
        const config= {
            headers:{"Authorization": token }
        };
        if( profileImage == "" || !profileImage ) {
            setProfileImageError(true);
            return null;
        }
        await axios.delete('http://localhost:9000/api/v1/profile/image',config)
                    .then((res)=>{
                        console.log(res);
                        setProfileImage('');
                    }).catch(err=>{
                        console.log(err);
                    })
    }

    const handleUpdateProfileImage = async (event)=>{
        event.preventDefault();
        const config= {
            headers:{"Authorization": token }
        };
        const data = {profileImage:event.target.value};
        await axios.patch('http://localhost:9000/api/v1/profile/image',data,config)
                    .then((res)=>{
                        console.log(res);
                        setProfileImage(data.profileImage);
                    }).catch(err=>{
                        console.log(err);
                    })
    }

    return (
        <>
            {isLoading && <div style={loadingStyle}> Loading ...</div>}
            {!isLoading && 
                <Form className="w-75" onSubmit={handleAddressChange}>
                    <Row className="mt-4">
                        <Col md={2}></Col>
                        <Col md={8}>
                            <Card>
                                <Card.Body>
                                    <Card.Text>
                                        <Row>
                                            <Col md={6}>
                                                <Row>
                                                    <Col md={12} className="content-align-center">
                                                        <img src={profileImage} className="rounded-circle" alt={profileImage}
                                                            data-testid="profile-image"></img>
                                                    </Col>
                                                </Row>
                                                {   
                                                    profileImageError &&
                                                    <Row>
                                                        <Col md={12} className="content-align-center">
                                                            <div className="alert alert-danger">
                                                                No image to delete
                                                            </div>
                                                        </Col>
                                                    </Row>
                                                }
                                                <Row>
                                                    <Col md={6}>
                                                        <Button variant="warning" type="button" data-testid="profile-delete-button"
                                                            onClick={handleDeleteProfileImage}>
                                                            Delete Image
                                                        </Button>
                                                    </Col>
                                                    <Col md={6}>
                                                        <Form.Control type="file" variant="primary" data-testid="profile-upload-button"
                                                            onChange={handleUpdateProfileImage}/>
                                                        {/* <Input variant="primary" type="file" data-testid="profile-upload-button"
                                                         onClick={handleUpdateProfileImage}>
                                                            Upload
                                                        </Input> */}
                                                    </Col>
                                                </Row>
                                            </Col>
                                            <Col md={6}>
                                                <Row>
                                                    <Col md={6}>
                                                        <Form.Group className="mb-3" controlId="formFirstname">
                                                            <Form.Label className="text-muted mb-0">Firstname</Form.Label>
                                                            <Form.Text className="mt-0 text-dark"><h5 data-testid="profile-first-name">{firstName}</h5></Form.Text>
                                                        </Form.Group> 
                                                    </Col>
                                                    <Col md={6}>
                                                        <Form.Group className="mb-3" controlId="formFirstname">
                                                            <Form.Label className="text-muted mb-0">Lastname</Form.Label>
                                                            <Form.Text className="mt-0 text-dark"><h5 data-testid="profile-last-name">{lastName}</h5></Form.Text>
                                                        </Form.Group> 
                                                    </Col> 
                                                </Row>
                                                <Form.Group className="mb-3" controlId="formEmail">
                                                    <Form.Label className="text-muted mb-0">Email</Form.Label>
                                                    <Form.Text className="mt-0 text-dark"><h5 data-testid="profile-email-name">{email}</h5></Form.Text>
                                                </Form.Group> 
                                                <Form.Group className="mb-3" controlId="formPhone">
                                                    <Form.Label className="text-muted mb-0">Phone</Form.Label>
                                                    <Form.Text className="mt-0 text-dark"><h5>{phone}</h5></Form.Text>
                                                </Form.Group> 
                                                <Form.Group className="mb-3" controlId="formInterests">
                                                    <Form.Label className="text-muted mb-0">Interests</Form.Label>
                                                    <Form.Text className="mt-0 text-dark"><h5>{interests}</h5></Form.Text>
                                                </Form.Group> 
                                                <Row className="mb-4">
                                                    <Col md={6}>
                                                        <Form.Group className="mb-3" controlId="formAddress">
                                                            <Form.Label className="text-muted mb-0">Address</Form.Label>
                                                            { isEditing && 
                                                            <>
                                                                <Form.Group className="mb-3" controlId="streetAddress">
                                                                    <Form.Label className="text-muted mb-0">Street Address</Form.Label>
                                                                    <Form.Control type="text" placeholder="" value={streetAddress} 
                                                                        onChange={e => {setStreetAddress(e.target.value)}}
                                                                        required/> 
                                                                </Form.Group> 
                                                                <Form.Group className="mb-3" controlId="city">
                                                                    <Form.Label className="text-muted mb-0">City</Form.Label>
                                                                    <Form.Control type="text" placeholder="" value={city} 
                                                                        onChange={e => {setCity(e.target.value)}}
                                                                        required/> 
                                                                </Form.Group> 
                                                                <Form.Group className="mb-3" controlId="formPhone">
                                                                    <Form.Label className="text-muted mb-0">State</Form.Label>
                                                                    <Form.Control type="text" placeholder="" value={state} 
                                                                        onChange={e => {setState(e.target.value)}}
                                                                        required/> 
                                                                </Form.Group> 
                                                                <Form.Group className="mb-3" controlId="zipCode">
                                                                    <Form.Label className="text-muted mb-0">Zip Code</Form.Label>
                                                                    <Form.Control type="text" placeholder="" value={zipCode} 
                                                                        onChange={e => {setZipCode(e.target.value)}}
                                                                        required/> 
                                                                </Form.Group> 
                                                            </>  
                                                            }
                                                            { !isEditing && 
                                                                <Form.Text className="mt-0 text-dark">
                                                                    <h5>
                                                                        {`${streetAddress}, ${city}, ${state} - ${zipCode}`}
                                                                    </h5>
                                                                </Form.Text>}
                                                        </Form.Group> 
                                                            {isEditing && <Button variant="primary" type="submit">Save</Button>}
                                                    </Col>
                                                    <Col md={6}>
                                                        {!isEditing && 
                                                            <Button variant="primary" type="button" onClick={handleEditBtnClick} data-testid="address-edit-button">
                                                                Edit
                                                            </Button>
                                                        }
                                                    </Col>
                                                </Row>
                                            </Col>
                                        </Row>
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                        </Col>
                        <Col md={2}></Col>
                    </Row>
                </Form>
            }
        </>
        
    )
}
