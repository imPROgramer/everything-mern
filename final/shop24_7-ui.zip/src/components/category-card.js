import {Card} from 'react-bootstrap';

const cardStyle= {
    "borderRadius":"5px",
    "margin":"10px",
    "width":'30%'
}

export function CategoryCard(props){
    let category=props.category;
    return (
        <Card style={cardStyle}>
            {/* <Card.Img variant="top" src={category.productImage} /> */}
            <Card.Body>
                {/* <Card.Title>{category.productName}</Card.Title> */}
                <Card.Text>
                    {category.name}
                </Card.Text>
            </Card.Body>
        </Card>
    )

}