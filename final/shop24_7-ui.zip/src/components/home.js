import { Products } from "./products";
import { Banner } from "./banner";
import {Row, Col } from "react-bootstrap";
import { CategoryCard } from "./category-card";
import axios from "axios";
import { useEffect, useState } from "react";

const rowStyle={
    "padding":" 0 12px"
}

export function Home(){

    let [myProducts,setMyProducts] = useState([]);
    let [categories,setCategories] = useState([]);

    // let myProducts= [{id:1234,productName:"P1"},{id:1212,productName:"P2"},
    //                 {id:1432,productName:"P3"},{id:1223,productName:"P4"},
    //                 {id:14332,productName:"P5"},{id:12523,productName:"P6"},
    //                 {id:144532,productName:"P7"},{id:12223,productName:"P8"}];

    // let categories= [{id:1234,name:"Category1"},{id:1212,name:"Category2"},
    //                 {id:1432,name:"Category3"}];


    const loadCategories = ()=>{
        axios.get('http://localhost:9000/api/v1/homepage/categories')
            .then((res)=>{
                console.log(res);
                console.log(res.data.categories);
                if(res.data.status == 'success' && res.data.categories.length > 0){
                    setCategories(res.data.categories);
                }else{
                    //hard coded some cartegories
                    setCategories([{id:1234,name:"Category1"},{id:1212,name:"Category2"},
                    {id:1432,name:"Category3"}]);
                }
            })
            .catch((err)=>{
                console.log(err);
            })
    };

    const loadTopProducts = async ()=>{
        await axios.get(' http://localhost:9000/api/v1/homepage/products')
            .then((res)=>{
                console.log(res);
                console.log(res.data.products);
                if(res.data.status == 'success' && res.data.products.length > 0){
                    setMyProducts(res.data.products);
                }else{
                    //hard coded some products
                    setMyProducts([{id:1234,productName:"P1"},{id:1212,productName:"P2"},
                    {id:1432,productName:"P3"},{id:1223,productName:"P4"},
                    {id:14332,productName:"P5"},{id:12523,productName:"P6"},
                    {id:144532,productName:"P7"},{id:12223,productName:"P8"}]);
                }
            })
            .catch((err)=>{
                console.log(err);
            })
    };

    useEffect(async ()=>{
        await loadCategories();
        await loadTopProducts();
    },[])

    return (
        <div className="w-75">  
            <Row>
                <Col md={12}>
                    <Banner data-testid="homepage-banner"></Banner>
                </Col>
                <Col md={12} className="d-flex justify-content-between" data-testid="homepage-category">
                    { categories.map((category)=><CategoryCard category={category}></CategoryCard> ) }
                    
                </Col>
            </Row>
            <Row>
                <Col md={12}> <h3>Top Products</h3></Col>
            </Row>
            <Row className="d-flex justify-content-between" style={rowStyle}>
                <Products products={myProducts} data-testid="homepage-product"
                    width={"20%"}></Products>
            </Row>
            
        </div>
    )
}