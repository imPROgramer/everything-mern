import {Navbar, Container, Nav} from 'react-bootstrap';

export function Header(){


    return(
        <Navbar bg="warning" variant="light">
            <Container>
                <Navbar.Brand href="/home">Shop 24x7</Navbar.Brand>
                <Nav className="me-auto">
                    <Nav.Link href="/home">Home</Nav.Link>
                    <Nav.Link href="/features">Departments</Nav.Link>
                    <Nav.Link href="/pricing">Offers</Nav.Link>
                    <Nav.Link href="/profile">Profile</Nav.Link>
                </Nav>
            </Container>
        </Navbar>)
}