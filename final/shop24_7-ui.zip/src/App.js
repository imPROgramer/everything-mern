import './App.css';
import { Login } from './components/login';
import { Profile } from './components/profile';
import { Home }  from './components/home';
import { CategoryProducts } from './components/category-products';
import { ProductPage } from './components/product-page';
import { Cart } from './components/carts';
import { BrowserRouter, Routes, Route } from "react-router-dom";

const alwaysCentered ={
  "display":"flex",
  "alignItems": "center",
  "justifyContent": "center"
}

function App() {
  return (
    <BrowserRouter>
      <div style={alwaysCentered} className="mb-4 pb-2">
        <Routes>
          <Route path="/login" element={<Login isLogin={true} />}></Route>
          <Route path="/register" element={<Login isLogin={false}/>}></Route>
          <Route path="/profile" element={<Profile/>}></Route>
          <Route path="/categories/:catergory_id" element={<CategoryProducts/>}></Route>
          <Route path="/products/:product_id" element={<ProductPage/>}></Route>
          <Route path="/cart" element={<Cart/>}></Route>
          <Route path="/" element={<Home/>}></Route>
        </Routes>
      </div>
    </BrowserRouter>
    
  );
}

export default App;

