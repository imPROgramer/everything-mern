module.exports={
    dburl: 'mongodb://127.0.0.1:27017/Food247',
    secret: 'food247', // secret for jwt
    port: 9000
}